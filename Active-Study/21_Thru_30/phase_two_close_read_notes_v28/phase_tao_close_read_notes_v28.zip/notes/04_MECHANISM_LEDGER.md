# Mechanism Ledger

This ledger is for stable mappings only. If a mapping requires changing definitions, move it to contradictions/open questions.

## Q: six-seat carrier / four-phase orbit

### Internal definition

```text
six seats = {+x, -x, +y, -y, +z, -z}
Q orbit = four equatorial seats by quarter-turn
axis/radix poles = two fixed/mediating seats
```

### External leads

| Source | External structure | Status | Notes |
|---|---|---|---|
| Shape of Understanding | 4 appearances + 2 builder states = 6-level reading | strong lead | Same 4-visible + 2-generator pattern, but not yet numeric Q. |
| 5d565 DDC math | Dao as pole/reference point, De as radius, DDC as circle | strong lead | Radix/radius/circle framework. |
| Chinese four-elements algebra / Britannica lead | center + four directions | queued | Need close-read actual included sources. |
| Taijitu / Yin-Yang geometry | circle, S-boundary, complementary phases | medium lead | Morphological, not enough by itself. |

## B: depth-9 Fibonacci/Farey corridor

### Internal definition

```text
B(u,v)=sort(v,u+v)
B^9(1,1)=(55,89)
uv=4895
r=1/4895
```

### External leads

| Source | External structure | Status | Notes |
|---|---|---|---|
| Shape of Understanding | repeated addition of Yin/Yang pair, binary tree | structural lead | Branch refinement exists; no floor-anchor proof yet. |
| Farey/Stern-Brocot/modular material | mediants / continued fractions / Farey graph | expected strongest | Need full source pass. |
| Chinese element methods | one/two/three/four unknown expansion | open | Check if expansion has path-depth/floor behavior. |

## L: lift / orthogonal re-articulation / re-chart

### Internal definition

```text
same-axis saturation/failure
→ orthogonal re-articulation
→ new carrier/chart/domain
→ carried state preserved while projection changes
```

### External leads

| Source | External structure | Status | Notes |
|---|---|---|---|
| Tao of Math | imaginary numbers on perpendicular axis; complex plane | exact mechanism-level lead | Blocked real-axis operation legalized by orthogonal axis. |
| Shape of Understanding | Pre-Heaven to Post-Heaven by middle-line inversion and center split | strong lead | Internal line-state change changes visible identity and arrangement. |
| Modular forms | SL2 lift vs PSL2 projection, S inversion | strong lead | Sign/phase retained in lift, collapsed in quotient. |
| Yin-Yang grid | coordinate singularity avoided by complementary overlapping chart | strong engineering lead | Re-charting instead of forcing one global coordinate frame. |

## Projection / witness loss

### Internal definition

Visible witness is not necessarily state-complete. Carried history/branch/lift may be erased by projection.

### External leads

| Source | External structure | Status | Notes |
|---|---|---|---|
| Modular forms | ± matrices act the same in PSL but differ in SL | strong lead | Exact quotient/projection-loss analogue. |
| Yijing | same primitives, different ordering, different hexagram meaning | medium lead | Needs frozen rule extraction. |
| Yin-Yang grid | same sphere, different coordinate patches/readouts | medium lead | Need figure pass. |

## Shadow / residual

### Internal definition

q-series / character-like residual with exponent/sign/support pattern.

### External leads

| Source | External structure | Status | Notes |
|---|---|---|---|
| Zagier modular forms | theta series, characters, eta-like q-series | strong lead | Need transform behavior. |
| Dedekind eta / eta powers | q^(1/24), product/series expansions | strong lead | Need coefficient and S/T transformation comparison. |


## Pass 33 mechanism additions

### TDAHE bridge template

```text
retained loop branch -> ordinary 2D projection residual -> branch-history register -> field-order commutator -> falsifiable measurement package
```

### Noncommutative bridge template

```text
visible projection unchanged while hidden order register changes; noncommutativity can live in branch/order extension rather than minimal Q/B/L state
```

### Inverse/Quintic scalar-discharge bridge

```text
finite scalar discharge fails; retained branch/fiber/root transport continues; terminal certificate/projection remains meaningful
```


## Pass 34 mechanisms added

### ICPR / Chinese logic
- `fa`: standard/model for admissible classification or inference.
- `lei`: kind/sameness-difference carrier.
- `xiao/pi/yuan/tui`: operation families over known/unknown, accepted/refused, same/different relations.
- Bridge: external method-normalization support for retained carrier + admissible operation.

### ICPR / automata-memory
- State + enabled transition + run word gives strong custody-selection analogue.
- Missing: floor-anchor law and L-lift condition.

### Unearthing Ancient Yi
- Three-line trigram = binary three-position/octal one-position carrier.
- Six-line hexagram = binary six-position/octal two-position/64-state carrier.
- Multiple readouts from same retained carrier: binary/octal/decimal/base64/computer-counting/cultural names.
- Orthad relevance: strong readout-transform layer; custody/successor law pending OCR/translation.
