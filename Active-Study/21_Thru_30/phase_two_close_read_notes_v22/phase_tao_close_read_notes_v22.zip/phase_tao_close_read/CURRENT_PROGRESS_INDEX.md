# Current Progress Index

Latest pass: `28_METHOD_LOCK_AND_BUDDHISM_CONTROL_PASS.md`

## Most recent artifact

- `notes/28_METHOD_LOCK_AND_BUDDHISM_CONTROL_PASS.md`

## Clarification locked

```text
"Retained state selects admitted operation" belongs to QBL custody / selection automation.
The Orthad lens matrix does not select operations.
The lens compiles the accrued Q/B/L word into active/latched channel structure.
```

Correct future wording:

```text
Retained state governs admissible Q/B/L custody moves;
the Orthad lens compiles the resulting word into active/latched channel structure;
terminal projection reads from that channel structure afterward.
```

## Current unified target

```text
Similarity is being tested at the mechanism level:
retained state -> admitted primitive custody move -> threshold/block -> re-chart/lift -> retained channel field -> downstream projection.
```

## Strongest active leads

```text
Q:
  Yijing/Gua finite position carrier;
  six-line retained object;
  Xiantian/Houtian state organization;
  Linggui Bafa remainder-position selector.

B:
  admitted-position / procedure-selector grammar;
  Dongyuan/Ceyuan contact-state formula legality;
  Q-admitted floor/capacity, not arbitrary depth.

L:
  Xiantian-Houtian re-chart;
  Yin-Yang computational grid re-chart;
  chart handoff through overlap/interpolation/conservation;
  modular S-inversion and automorphy factor;
  Tianyuan/Four-Elements algebraic lift.

Shadow:
  eta/unary theta chi12 q^(n^2/24);
  target: Jacobi-variable derivative gives chi12(n)*n*q^(n^2/24);
  compare retained channel field before scalar q-series projection.
```

## Current cautions

```text
Selector-complete macro calculus is stale and not canonical.
Phase docs/code are snapshots, not the full active framework.
Do not overfit Chinese sources to depth=nine.
Do not collapse distinct NOT/reversal/reflection/re-chart operations.
Do not compare scalar projections before retained channel fields.
Do not say Shadow residual is eta; eta lacks the extra n coefficient.
Yin-Yang chart handoff must preserve invariants; smooth projection alone is insufficient.
```

## Latest coverage status artifact

```text
notes/21_PERCENT_COVERAGE_STATUS.md
coverage_percent_status.csv
```

## Pass 25 update

```text
Liu_2022_ApJ_940_62.pdf moved to COMPLETE_FIRST_PASS.
Main result: data-constrained MHD is strongest as topological custody/projection discipline, not direct QBL. HFT/null-point reconnection separates an upper erupting hot channel from a lower stable filament; synthetic AIA 94/304 and line-of-sight integration are terminal projections from retained 3D state.
```

Next active target:

```text
Prospect-Leads/Physics_of_Buddhism_The_physics_and_math.pdf
```

## Latest correction - pass 26

Added: `notes/26_RIGOR_CORRECTION_LIU_BRIDGE_NOT_EXHAUSTED.md`

Main correction:

```text
Do not downgrade Liu 2022 Q/B bridges as weak before bridge-specific comparison is exhausted.
```

Replaced with:

```text
DIRECT_MATCH_UNPROVEN
BRIDGE_OPEN
NOT_YET_EXHAUSTED
```

## Latest addition: Liu 2022 bridge perspective pass

Added:

- `notes/27_LIU_QBL_BRIDGE_PERSPECTIVE_PASS.md`

Status update:

```text
Liu 2022 is now classified as:
  LIU_2022_BRIDGE_OPEN_AND_HIGH_VALUE

not:
  weak direct Q/B support
```

Reason:

```text
The squashing-factor Q name-match is false as primitive Q,
but the diagnostic/operator/threshold/lift/projection bridges remain open and high-value.
```


## Latest addition: pass 28 method lock and Buddhism control-corpus pass

```text
Phase Calculus/QBL is not being framed as Taoist math.
External Taoist/Chinese/Yijing/Buddhist/modern computational sources are comparison corpora.
Research criterion is functional overlap, not names.
Bridges remain open unless an explicit functional negative test closes them.
```

`Prospect-Leads/Physics_of_Buddhism_The_physics_and_math.pdf` is now COMPLETE_FIRST_PASS_AS_CONTROL_CORPUS. It is useful for distinguishing element-dual, observer-dual, full-negation, re-chart, and projection operations.
