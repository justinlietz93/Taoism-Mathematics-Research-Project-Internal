# Mechanism Ledger

This ledger is for stable mappings only. If a mapping requires changing definitions, move it to contradictions/open questions.

## Q: six-seat carrier / four-phase orbit

### Internal definition

```text
six seats = {+x, -x, +y, -y, +z, -z}
Q orbit = four equatorial seats by quarter-turn
axis/radix poles = two fixed/mediating seats
```

### External leads

| Source | External structure | Status | Notes |
|---|---|---|---|
| Shape of Understanding | 4 appearances + 2 builder states = 6-level reading | strong lead | Same 4-visible + 2-generator pattern, but not yet numeric Q. |
| 5d565 DDC math | Dao as pole/reference point, De as radius, DDC as circle | strong lead | Radix/radius/circle framework. |
| Chinese four-elements algebra / Britannica lead | center + four directions | queued | Need close-read actual included sources. |
| Taijitu / Yin-Yang geometry | circle, S-boundary, complementary phases | medium lead | Morphological, not enough by itself. |

## B: depth-9 Fibonacci/Farey corridor

### Internal definition

```text
B(u,v)=sort(v,u+v)
B^9(1,1)=(55,89)
uv=4895
r=1/4895
```

### External leads

| Source | External structure | Status | Notes |
|---|---|---|---|
| Shape of Understanding | repeated addition of Yin/Yang pair, binary tree | structural lead | Branch refinement exists; no floor-anchor proof yet. |
| Farey/Stern-Brocot/modular material | mediants / continued fractions / Farey graph | expected strongest | Need full source pass. |
| Chinese element methods | one/two/three/four unknown expansion | open | Check if expansion has path-depth/floor behavior. |

## L: lift / orthogonal re-articulation / re-chart

### Internal definition

```text
same-axis saturation/failure
→ orthogonal re-articulation
→ new carrier/chart/domain
→ carried state preserved while projection changes
```

### External leads

| Source | External structure | Status | Notes |
|---|---|---|---|
| Tao of Math | imaginary numbers on perpendicular axis; complex plane | exact mechanism-level lead | Blocked real-axis operation legalized by orthogonal axis. |
| Shape of Understanding | Pre-Heaven to Post-Heaven by middle-line inversion and center split | strong lead | Internal line-state change changes visible identity and arrangement. |
| Modular forms | SL2 lift vs PSL2 projection, S inversion | strong lead | Sign/phase retained in lift, collapsed in quotient. |
| Yin-Yang grid | coordinate singularity avoided by complementary overlapping chart | strong engineering lead | Re-charting instead of forcing one global coordinate frame. |

## Projection / witness loss

### Internal definition

Visible witness is not necessarily state-complete. Carried history/branch/lift may be erased by projection.

### External leads

| Source | External structure | Status | Notes |
|---|---|---|---|
| Modular forms | ± matrices act the same in PSL but differ in SL | strong lead | Exact quotient/projection-loss analogue. |
| Yijing | same primitives, different ordering, different hexagram meaning | medium lead | Needs frozen rule extraction. |
| Yin-Yang grid | same sphere, different coordinate patches/readouts | medium lead | Need figure pass. |

## Shadow / residual

### Internal definition

q-series / character-like residual with exponent/sign/support pattern.

### External leads

| Source | External structure | Status | Notes |
|---|---|---|---|
| Zagier modular forms | theta series, characters, eta-like q-series | strong lead | Need transform behavior. |
| Dedekind eta / eta powers | q^(1/24), product/series expansions | strong lead | Need coefficient and S/T transformation comparison. |


## v46 TDAHE retained branch / quotient residual mechanism

- Carrier: through-thickness loop plus branch registers `(h_y,h_z)`.
- Projection collision: planar projection can agree while retained moment changes sign.
- Admissible operations: field-training updates `U_y`, `U_z`.
- Noncommutation: `[U_y,U_z]=alpha beta diag(1,-1)`.
- Readout: Hall residual/order signal is terminal projection from retained branch memory.
- Negative control: scalar `h_z` alone is not state-complete when `U_y` depends on `h_y`.


## v47 branch grammar mechanism ledger

- Universal branch grammar: retained branch surface + generator registry + sheet/history word -> lifted execution -> quotient/readout.
- Negative control: S5 generators share primitive operator word `L Q` while carrying different finite sheet actions. Primitive word-only projection fails state completeness.
- Bridge rule strengthened: readout/operator/scalar channel is only acceptable as carried object when it determines the next admissible transition.


## v48 Pencil Code Yin-Yang mechanism

| Mechanism | Evidence | Bridge status |
|---|---|---|
| Self-inverse chart map | `yin2yang_coors.pro`; SymPy A^2=I, det=+1 | STRONG_L_RECHART_BRIDGE |
| Vector/scalar split | `yinyang.f90` transforms vector basis before interpolation but scalar directly | STRONG_STATE_COMPLETENESS_GATE |
| Gap/cap boundary completion | `yinyang_mpi.f90` zsum/reduce_zsum weighted contributions | STRONG_BOUNDARY_CUSTODY_BRIDGE |
| Dummy negative control | `noyinyang.f90` stops active routines | STRONG_NEGATIVE_CONTROL |


## v49 mechanism ledger addition

| Mechanism | Status | Evidence | Bridge use |
|---|---:|---|---|
| Hidden order commutator | STRONG_INTERNAL_GATE | [a,b]=(0,0,1) while visible([a,b])=(0,0) | Projection/readout is terminal unless hidden order register is retained |
| Sheet commutator | STRONG_INTERNAL_GATE | [(12),(23)] = (132) | Operation registry/sheet action is retained state |
| Balanced corridor anchor | CANONICAL_ORIGIN_WITNESS | B^9 from (1,1) reaches (55,89), uv=4895 | Supports origin-path evidence without constraining arbitrary starts |
| Non-origin B corridors | SCOPE_CORRECTION_CONFIRMED | starts (1,3),(2,13),(3,10),(7,11) tabulated | Prevents rigid semantic drift in B comparison |


## v51 Mechanism: monodromy/history register

| Mechanism | Status | Bridge use |
|---|---:|---|
| Sheet/kappa/history retained register | STRONG_INTERNAL_GATE | State-complete branch custody; visible projection is non-faithful. |
| Double-cover visible collision | NEGATIVE_CONTROL_PASS | Same visible projection does not imply same full transition. |
| Quintic commutator nonidentity | OPERATOR_ORDER_GATE | Generator action/order is retained state, not metadata. |


## v52 Mechanism: CF19 executable/data spine

| Mechanism | Status | Bridge use |
|---|---:|---|
| Farey anchor `(55,89)` | CONFIRMED_ORIGIN_WITNESS | B from canonical/smallest lifts reaches uv=4895 floor anchor. |
| Non-origin B corridors | CONFIRMED_SCOPE_GATE | B can begin from arbitrary/asymmetric `(u,v)` and may hit different floor anchors. |
| Xi field register | STATE_COMPLETENESS_GATE | Word/q projection is insufficient without A/theta/kappa/floor/window/carry fields. |
| Tdelta transfer/reset | STALE_OR_BRANCH_LOCAL_WITNESS | Useful executable witness but not corrected Orthad L. |
| Ramanujan residual window | TERMINAL_EXTERNAL_COMPARISON_CHANNEL | Coefficients support 1/24 and 1/12 targets but do not close Shadow Residual. |
