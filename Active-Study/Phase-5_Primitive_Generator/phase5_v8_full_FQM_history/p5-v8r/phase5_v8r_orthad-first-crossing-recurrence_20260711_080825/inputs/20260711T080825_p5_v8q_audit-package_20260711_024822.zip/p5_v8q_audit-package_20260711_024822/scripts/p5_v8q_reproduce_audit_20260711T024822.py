#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

CLAIMED_SHA = "625a2587e160ed39c5a18cce4c0e00ec15544608776f65b2aac785d233ff4131"
EXPECTED_WORD = "BQQBBBQBQBBQBBL"
EXPECTED_FLOOR = [55, 89]
EXPECTED_NEXT = [89, 144]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_json(path: Path) -> object:
    return json.loads(path.read_text())


def find_root(extracted: Path) -> Path:
    roots = [p for p in extracted.iterdir() if p.is_dir()]
    if len(roots) != 1:
        raise RuntimeError(f"expected one package root, found {roots}")
    return roots[0]


def verify_manifest(root: Path) -> tuple[bool, list[str]]:
    manifest = load_json(root / "MANIFEST.json")
    expected = {row["path"]: row for row in manifest["files"]}
    actual = {
        str(path.relative_to(root)): path
        for path in root.rglob("*")
        if path.is_file() and path.name != "MANIFEST.json"
    }
    errors: list[str] = []
    if set(expected) != set(actual):
        errors.append(f"path mismatch missing={sorted(set(expected)-set(actual))} extra={sorted(set(actual)-set(expected))}")
    for rel, row in expected.items():
        path = actual.get(rel)
        if path is None:
            continue
        data = path.read_bytes()
        if len(data) != row["bytes"]:
            errors.append(f"byte mismatch {rel}")
        if hashlib.sha256(data).hexdigest() != row["sha256"]:
            errors.append(f"sha mismatch {rel}")
    return not errors, errors


def run_command(args: list[str], cwd: Path, env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, cwd=cwd, env=env, text=True, capture_output=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("--rebuild", action="store_true")
    ns = parser.parse_args()
    archive = ns.archive.resolve()
    if not archive.is_file():
        raise SystemExit(f"archive not found: {archive}")

    report: dict[str, object] = {
        "archive": str(archive),
        "actual_sha256": sha256(archive),
        "response_declared_sha256": CLAIMED_SHA,
    }
    report["sha_matches_response"] = report["actual_sha256"] == CLAIMED_SHA

    with tempfile.TemporaryDirectory() as td:
        extracted = Path(td) / "extracted"
        extracted.mkdir()
        with zipfile.ZipFile(archive) as zf:
            zf.extractall(extracted)
        root = find_root(extracted)
        report["package_root"] = root.name

        manifest_ok, manifest_errors = verify_manifest(root)
        report["manifest_verified"] = manifest_ok
        report["manifest_errors"] = manifest_errors
        manifest = load_json(root / "MANIFEST.json")
        report["manifest_files"] = len(manifest["files"])

        env = dict(os.environ)
        env["PYTHONPATH"] = str(root / "src")
        env["PYTHONDONTWRITEBYTECODE"] = "1"

        verify = run_command(
            [sys.executable, "scripts/20260711_072509_verify.py", "."],
            root,
            env,
        )
        report["verifier_exit_code"] = verify.returncode
        if verify.returncode == 0:
            payload = json.loads(verify.stdout)
            report["verifier_verified"] = payload["verified"]
            report["verifier_gates_total"] = len(payload["gates"])
            report["verifier_gates_passed"] = sum(bool(x["passed"]) for x in payload["gates"])
        else:
            report["verifier_stdout"] = verify.stdout
            report["verifier_stderr"] = verify.stderr

        tests = run_command([sys.executable, "-m", "pytest", "-q", "tests"], root, env)
        report["pytest_exit_code"] = tests.returncode
        report["pytest_stdout"] = tests.stdout.strip()

        boundary = load_json(root / "outputs/20260711_072509_boundary_results.json")
        report["boundary"] = boundary
        report["primitive_boundary_matches"] = (
            boundary.get("crossing_word") == EXPECTED_WORD
            and boundary.get("floor_pair") == EXPECTED_FLOOR
            and boundary.get("floor_product") == 4895
            and boundary.get("q_steps") == 5
            and boundary.get("post_l_pair") == EXPECTED_FLOOR
            and boundary.get("first_next_domain_pair") == EXPECTED_NEXT
        )

        controls = load_json(root / "outputs/20260711_072509_control_results.json")
        report["controls_total"] = len(controls)
        report["controls_fired"] = sum(bool(x.get("target_gate_fired")) for x in controls)

        orthad = load_json(root / "outputs/20260711_072509_orthad_derivation_boundary.json")
        report["orthad_boundary_snapshot"] = {
            "observed_ticks": orthad.get("observed_ticks"),
            "observed_word_prefix": orthad.get("observed_word_prefix"),
            "status": orthad.get("status"),
        }
        report["orthad_named_boundary_is_post_next_B"] = orthad.get("observed_word_prefix") == EXPECTED_WORD + "B"

        assumption = (root / "inputs/20260711_072509_ASSUMPTION_LOCK.md").read_text()
        report["assumption_lock_bans_rank"] = "`search`, `scan`, `rank`, and `test`" in assumption

        if ns.rebuild:
            rebuilt = Path(td) / "rebuilt"
            shutil.copytree(root, rebuilt)
            build = run_command(
                [sys.executable, "scripts/20260711_072509_rebuild.py", "."],
                rebuilt,
                {**env, "PYTHONPATH": str(rebuilt / "src")},
            )
            report["rebuild_exit_code"] = build.returncode
            report["rebuild_stdout"] = build.stdout.strip()
            stable = [
                "outputs/20260711_072509_boundary_results.json",
                "outputs/20260711_072509_statuses.json",
                "trace/20260711_072509_primitive_first_crossing_trace.jsonl",
            ]
            report["stable_semantic_outputs_equal"] = all(
                (root / rel).read_bytes() == (rebuilt / rel).read_bytes() for rel in stable
            )
            compare = []
            for rel in sorted(set(
                str(p.relative_to(root)) for p in root.rglob("*") if p.is_file()
            ) & set(
                str(p.relative_to(rebuilt)) for p in rebuilt.rglob("*") if p.is_file()
            )):
                if (root / rel).read_bytes() != (rebuilt / rel).read_bytes():
                    compare.append(rel)
            report["rebuilt_byte_differences"] = compare

    print(json.dumps(report, indent=2, sort_keys=True))
    ok = bool(report.get("manifest_verified")) and bool(report.get("primitive_boundary_matches"))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
