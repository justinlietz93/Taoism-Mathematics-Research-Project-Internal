# PHASE 5 CANONICAL LEDGER
Authority rule: this file outranks any package headline, status string, or agent summary.
A claim is ACTIVE TRUTH only if it appears in §3. Package docs are evidence; this ledger is state.
Agent protocol: read this ledger before starting any pass. Reconcile your claim_disposition rows
against §3 and §5 before writing a package. Any new term must be registered in §4 before first use
in a STATUS string. Decision log (§7) is append-only.

Last updated: 2026-07-09 (v8i audited: provenance patch verified; splitter failure DIAGNOSED as missing radical block type, 229/229; v8j commissioned)

---

## 1. NORTH STAR (frozen; edit only via §7 entry)

Phase Calculus claims every observation splits into retained state and projected shadow, and that
projection loss is lawful (a gate, not noise). Phase 5 tests whether this gate already exists inside
mathematics: the conjecture is that the shadow map of mock-modular theory (mock theta -> shadow theta,
carried by finite quadratic modules / the Weil representation) IS the projection-loss gate.
The Orthad is the primary object: a two-lens (overset) system over retained QBL history whose
gauge/isometry class defines retained content. The mock-modular correspondence is one external anchor;
the Liu2022 MHD system is the second (physical) anchor. Same theorem, two substrates.

## 2. SPINE (the layer diagram)

overset lenses (chimera charts, neither privileged)
  -> transition records T (overlap handoffs; v7q)
  -> confluence + cocycle (atlas consistency; v8a: diamonds 20736/20736, cocycle residual 0 mod 12)
  -> holonomy (loop content; parity latch / lap bit = first Z/2 rung)
  -> gauge/isometry class = retained truth (raw C demoted to chart artifact; v7m/v7n)
  -> FQM = finite carrier of the gauge class; isometry = "same retained content"
  -> classifier = equality decision procedure for retained content (v7r/v7s/v8b)

Bloch/metaplectic dictionary (origin of the program's key recognition):
lifted object=S3 phase-carrying state | shadow=Bloch sphere | scalar cargo=U(1) fiber (lawfully
discarded; v7i reframe) | parity latch=discrete holonomy / Berry bit | lap2=-lap1 = double-cover
signature (metaplectic; eta multiplier) | T-phase 1/24 = eta phase | vchi Fourier-fixed =
finite oscillator ground state. Prediction (falsifiable): richer admissible loops should retain
finer roots of unity than Z/2 (FQM side has them at level 24). v8d doubles as this test.

## 3. STATUS BOARD

### ACTIVE TRUTH
- Orthad bridge end-to-end on finite instances: retained QBL -> admissibility -> T -> cocycle class
  -> FQM presentation -> gauge class. [v7p–v7u, v8a]
- v8a conditional closure: all-history confluence + cocycle compatibility inside the defined
  admissible retained QBL system. Lean proof OPEN. [v8a, phase5_closed=false]
- Raw coordinate matrix C is NOT invariant (CLOSED_NEGATIVE, adversarially controlled). [v7m, v8b]
- Z/12Z chi12 shadow-skeleton identification: FQM = discriminant form of <12>; K12·vchi = vchi with
  vchi distinguished (impostors rejected); T-phase locked r^2≡1 mod 24 -> q=1/24; depth 3–6 channel
  match with zero scalar cargo. [v7x SHA 6bbc9bf1, v7z SHA f6ae4d77 under corrected label]
- Parity latch necessity: mod 6 cannot carry chi12; one-bit lift to mod 12 forced; same bit is lap
  orientation (lap2 = -lap1). [v7w, v7x]
- Arbitrary coprime starts are recoverable retained ladder state; Fibonacci origin demoted to one
  admitted start; terminal projection signature NOT state-complete (collision witnesses). [v7y SHA 38007f62]
- v8b exact subclass closures: doubled-cyclic classifier N<=96; odd-prime rank-2 GL(2,p) orbits
  p in {3,5,7,11} (2 classes per prime by det square-class); direct-sum Jordan symbol permutation
  invariance; 2-primary odd-block normalization; structural keys for large rank (keys only, not
  isometry proof). [v8b SHA 816002a5]
- Liu2022 external-data bridge: raw 3D MHD cubes received (736 files, NCAR Globus) + Tie Liu
  post-processing scripts (AIA 94/304 synthesis, squashing factor). Physical anchor at data intake.
- v8d family F derivation (CONDITIONAL on defined T-record alphabet): every Orthad-generated FQM
  presentation lands in F = products of even doubled-cyclic carriers Z/D_iZ with diagonal x_iy_i/D_i
  plus representative-invariant pairwise edges c_ij/(lcm), c_ij multiple of lcm/gcd (= well-definedness).
  Proof: arity induction over alphabet (Q/B/L unary -> diagonal; O_ij binary -> pairwise edge; R terminal).
  [v8d SHA 8aba228e]
- Cross-coupled presentations ARE reachable from Orthad T records (36 D-pair witnesses; O_ij repetition
  hits every representative-invariant residue). v8c premise REFUTED; v8c stays suspended. [v8d]
- Trilinearity gate holds: no nondecomposable triple incidence generated in defined system; genuine
  triple tau and rank-3 C-tensor injections rejected; boundary triples decompose to pairwise. [v8d 4/4]
- Z/12Z chi12 skeleton REACHABLE (single D=12 unary carrier; support/q/Fourier verified 5.1e-15).
  Correspondence bridge survives its decisive test. [v8d]
- 2-primary wall is REAL for the generated image: even/mixed cross-coupled witnesses (e.g. D8-D8 c2,
  D8-D16 c2, D12-D24 c2) require full 2-adic isometry classification. Outcome (b) of commission. [v8d]
- v8e size-2 Family-F isometry classifier CLOSED on D range [2..32 listed], 78 pairs, by exact
  Aut-orbit enumeration. INDEPENDENTLY VERIFIED: (8,8) orbits reproduced by from-scratch brute-force
  full-form-equality decider (classes {0,4},{1,7},{2,6},{3,5} identical). [v8e; external audit 2026-07-09]
- Compact invariant set (|A|, Gauss-Milgram sig mod 8, oddity, p-excess) is NOT complete for size-2:
  CLOSED_NEGATIVE with named residual walls at (8,8),(8,24),(8,32),(24,24)x2,(24,32),(32,32) —
  e.g. c=0 vs c=2 on (8,8) share full key, distinct orbits. Exact orbit table remains the classifier.
  This is the Conway-Sloane subtlety appearing exactly where predicted (2-primary, 8|D). [v8e]
- Cross-shape rigidity (AUDIT-ADDED, empirical): all four same-group shape aliases in range —
  (4,6)/(2,12), (6,8)/(2,24), (4,10)/(2,20), (8,12)/(4,24) — admit ZERO cross-shape isometries
  (exhaustive generator-image search). Family diagonal q(e_i)=1/(2D_i) appears to rigidify shape.
  Status: CONJECTURED_LEMMA_EMPIRICALLY_GATED; v8e's completeness claim silently assumed it. [audit]
- v8d patches DONE: chi12 skeleton via executed T-trace using v7w seat/latch semantics (pre-L mod6,
  latch bit, post-L mod12 — consistent with arc, not re-derived wrong); archival v7t/v7u routed
  (v7t: 7 size-2 classified, 3 rank-3 blocked; v7u: 7 rank>=3 blocked). [v8e]
- v8f rank-3 EQUAL 2-primary CHAIN classifier CLOSED on tested range (D=4 all 16, D=8 all 64,
  D=16 even-c margin) by exact pullback-form isometry (generator-image + polarization + det-odd
  invertibility, valid for 2-power D). INDEPENDENTLY VERIFIED: external audit re-classified all
  D=4 chains from scratch -> identical 5 classes, class-by-class. [v8f SHA 47a4bd94; audit 07-09]
- Split-first is real and load-bearing: 38 secretly-split connected controls caught. Flagship
  (1,0,4)->(0,0,1) at D=8 independently confirmed with explicit witness + pointwise equality over
  all 512 elements. Audit also independently rediscovered (2,0,2)~(0,0,0) at D=4. Connectivity
  is officially NOT an isometry invariant (CLOSED_NEGATIVE, enforced). [v8f + audit]
- Archival: v7t 3/3 rank-3 cases classified in equal D=8 chain range; v7u 7/7 routed, all
  BLOCKING_OPEN as mixed/high-rank. Cross-shape rigidity NOT used as theorem (compliant). [v8f]
- v8g triangle closure VERIFIED: full D=4+D=8 equal-D rank-3 parameter spaces (64+512 forms) carry
  dispositions, zero missing; audit independently re-classified ALL 64 D=4 forms (partition match)
  and all 27 D=4 triangle dispositions (match); 8/8 stratified D=8 samples verified incl. exhaustive
  non-isometry certificates. v8f scope hole CLOSED. [v8g SHA 60980acd; audit 07-09]
- Mixed [2,4,2] rank-3 classifier VERIFIED: audit re-classified all 8 forms independently
  (bijectivity by image cardinality, valid for mixed shapes) -> identical 6 classes. Closes v7u
  rank3_mixed. [v8g + audit]
- Cross-shape rigidity RESOLVED for pure 2-primary shapes by cyclic-order multiset uniqueness
  (fundamental theorem of finite abelian p-groups): no same-group aliases exist post-p-primary-split.
  Mixed original shapes remain empirically gated only. [v8g]
- Scope-completeness gate ADOPTED as standing control (enumerate full stated parameter space;
  any form without a disposition row fails the package). [v8g, from v8f audit]
- v8h rank-4 [4,4,2,16] same-shape classifier VERIFIED: 512/512 forms, 14 classes. Audit re-verified
  all 498 positive witnesses pointwise; independent (order,q)-multiset fingerprint constant within
  every class (0 violations); single cross-class fingerprint collision separated by independent
  exhaustive search. Pre-grouping by q-histogram proven sound (true invariant) and leader algorithm
  complete. Closes v7u rank4_mixed. [v8h SHA c9c241dc; audit 07-09]
- Compact invariants again incomplete at rank 4 (collision groups harvested) — consistent with the
  v8e finding; genus-symbol layer remains the eventual fix. [v8h]
- v8i provenance patch VERIFIED: all 7 restored edge lists match v8g exactly (41/62 for rank10/12);
  agent's own diff additionally caught rank3_mixed (3 edges), missed by prior audit scope. The
  provenance gate works. [v8i SHA 2cc821d2; audit 07-09]
- SPLITTER FAILURE DIAGNOSED (audit): split_success <=> trivial radical, 229/229 rows, zero
  exceptions. Splitter achieves 100% on nondegenerate forms (138/138) and 0% on degenerate (0/91):
  the pivot search (unit-A or invertible equal-level UV) can never consume a radical vector. The
  CLOSED_NEGATIVE was honest bookkeeping but the path is NOT dead — the block alphabet is missing a
  RADICAL block type. Wall/Kawauchi-Kojima untouched (guarantees are for nondegenerate forms).
  Worked completion verified: [2,2]c01=1 = A_2(1) PERP R_2(q=0), pointwise. [audit 07-09]

### SUSPENDED (do not use as truth; do not delete)
- v8c "PHASE5_CLOSED=true (native Orthad scope)". Premise REFUTED by v8d (cross-coupled reachable);
  closure not sound retroactively. Remains suspended until wall-for-F is closed or re-scoped. [v8c, v8d]

### DEPRECATED (never reuse)
- Label "concrete mock-theta FQM matching = CLOSED_POSITIVE" (v7z original headline). No mock theta
  was computed; object was the shadow skeleton. Corrected in v8c disposition ("v7z-corrected").
- Raw C as target/invariant (pre-v7m framing).
- "Odd N is a boundary/defect" framing (v7i reframe: it is the gate firing).

## 4. NAMING REGISTRY (term -> earned meaning; forbidden reading)
- Orthad: overset dual-lens system over retained QBL history. NOT a single matrix.
- retained state: content invariant under admissible lens change (gauge class). NOT "what the
  program happens to store."
- shadow / projection loss: lawful discard under projection (scalar cargo SHOULD vanish). NOT failure.
- shadow skeleton: finite chi12 carrier on Z/12Z (support {1,5,7,11}, q=r^2/24). NOT a mock theta.
- mock-theta correspondence: shadow map = projection-loss gate for an ACTUAL mock/false theta
  (requires q-series; grep-mock test: no q-series in computation = term forbidden). OPEN, out-of-phase.
- classifier: decision procedure for FQM isometry. "Structural key" is NOT a classifier
  (keys separate; only full invariants + completeness prove isometry).
- CLOSED_POSITIVE: gate-checked on-page within stated scope. Scope column mandatory.
- holonomy / latch: retained loop content (currently Z/2). NOT bookkeeping convention.

## 5. OPEN TARGETS (five-disposition law: targets may not vanish)
- v8d Orthad-generated FQM subclass derivation — BLOCKING_OPEN, CURRENT TARGET. Load-bearing steps:
  (a) prove/refute cross-coupled reachability from Orthad T records; (b) test whether Z/12Z chi12
  skeleton is in the generated image. (b) unreachable => contradiction-grade for the correspondence.
  Downstream: SymPy classifier for the generated subclass; run on v7t, v7u, corrected-v7z objects.
- Full p^k mixed cyclic Jordan decomposition — BLOCKING_OPEN unless v8d proves unreachable.
- Full 2-adic Nikulin/Conway-Sloane classification — BLOCKING_OPEN unless v8d narrows image.
- Lean-verified executable classifier + all-history proof — DEFERRED_TO_FINAL_PROOF_PASS.
- Analytic q-series completion / actual mock-theta object — DEFERRED_OUT_OF_PHASE (hard reason:
  requires infinite q-series; Phase 5 is the finite carrier phase). PRIMARY target of next phase.
- Orthad field-valued channels (projection weights in overlap; vector/tensor component transformation)
  — OPEN, required before MHD arm can load the lens. [overset source constraints]
- Liu2022 intake: reader/units/grid verification; frame indices for pre-eruption / tether-cutting /
  ejection — OPEN, physical arm only; do not interleave with v8d.

## 6. GUARDRAIL LESSONS (why this ledger exists)
- v7v: targets were forgotten and had to be recovered -> cross-package memory cannot live in packages.
- v7z: headline claimed a layer the proof didn't reach; gates all passed -> gates check math,
  not names. Naming registry is the missing gate.
- v8c: honest-looking deferral hid an unproven reachability premise -> every deferral must state
  the premise that makes it out-of-scope, and that premise gets a target row.
- Frontier character shift (post-v7y): once targets stop being finite sweeps, watch for
  finite-checks-booked-as-theorems. Conditional closures must carry their condition in the STATUS string.

## 7. DECISION LOG (append-only; date, decision, reason, evidence)
- 2026-06-xx v7m: target corrected raw C -> gauge/holonomy/FQM class. Reason: C varies under lens
  change. Evidence: v7m docs; v8b raw_matrix negative control.
- 2026-06-xx v7i: odd-N and scalar-cancellation reframed as gate-firing, not defect.
- 2026-07-08 v7z label corrected to shadow-skeleton FQM identification. Reason: no q-series in
  computation. Evidence: grep mock = 0; split witnesses show integer lift outside FQM.
- 2026-07-08 v8c closure SUSPENDED. Reason: hidden reachability premise on cross-coupled deferral.
- 2026-07-08 v8d adopted as current target (classify the generator's image, not the universe).
  Reason: converts 2-adic wall into possibly-avoidable wall; decides v8c; tests the bridge to the
  correspondence via skeleton reachability.
- 2026-07-08 Bloch/metaplectic dictionary registered (§2) with falsifiable prediction (finer roots
  of unity as retained loop content).
- 2026-07-09 v8d adopted: outcome (b). Family F derived (conditional on alphabet); cross-coupled
  reachable -> v8c premise refuted, stays suspended; skeleton reachable -> bridge survives;
  trilinear gate holds -> FQM carrier sufficient for current alphabet. Two patch obligations logged.
- 2026-07-09 v8e commissioned: classify the wall restricted to F via coupling-graph decomposition;
  exact orbit ground truth at rank 2; Gauss-Milgram added to invariant set.
- 2026-07-09 v8e ADOPTED after independent re-execution + adversarial cross-shape audit (4 alias
  pairs, 0 hits). Invariant-incompleteness CLOSED_NEGATIVE accepted as a real result. Evasion
  watch-item did NOT materialize: hard deliverable (orbit ground truth) was the centerpiece.
- 2026-07-09 v8f commissioned: rank>=3 via p-primary splitting first (odd parts diagonalize),
  2-primary core by bounded exact orbits; splitting-reduction gate before rank>=3 booking.
- 2026-07-09 v8f ADOPTED after independent verification (D=4 full re-classification match;
  flagship split confirmed pointwise). One audit finding: equal-D triangles unbooked -> new
  BLOCKING_OPEN row added; naming was honest ('chain classifier') but the disposition set was
  incomplete. v8g commissioned: triangles + mixed/high-rank via Jordan-block reduction.
- 2026-07-09 v8g ADOPTED after full independent replication at D=4 (all 64 forms) and [2,4,2]
  (all 8 forms), plus 8/8 stratified D=8 verifications. Triangle hole closed; scope gate adopted;
  pure-2-primary rigidity resolved by multiset uniqueness. Split-semantics limit documented as
  standing constraint. v8h commissioned: rank-4 [4,4,2,16] exact closure; rank>=5 reduction-first.
- 2026-07-09 v8h rank-4 ADOPTED (fully verified). Finding: rank10/12 edge data lost in
  transcription -> patch obligation + standing provenance gate. v8i commissioned:
  extended-diagonal block decomposition (Wall normal form) to reduce rank>=5 cores to rank-1/rank-2
  blocks; validate decomposition against rank<=4 orbit ground truth; catalog observed
  symbol-equivalence relations (oddity fusion / sign walking) empirically against ground truth.
- 2026-07-09 v8i ADOPTED (provenance patch verified; splitter honestly booked CLOSED_NEGATIVE).
  Audit REFRAMED the negative: failure <=> nontrivial radical (229/229), so the defect is a missing
  radical block type, not a structural wall. v8j commissioned: radical-first decomposition,
  measure non-summand radicals, 229/229 target, then rank>=5 cores.

## 8. NEXT
Single active target: v8j (radical-aware block decomposition; 229/229 ground truth, then rank>=5
cores). Everything else waits or runs on the physical arm without touching v8j.
