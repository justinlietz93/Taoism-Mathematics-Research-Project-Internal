# Canonical Research Trunk

**Revision:** v5  
**Primary semantic authority:** `QBL_PRIMITIVE_CUSTODY_AND_ORTHAD_LAW_v2.md`  
**Purpose:** Preserve the current intended behavior of the primitive engine, lifted object, and Orthad while separating semantic canon from still-open algebraic realization.

## 0. Authority rule

The supplied `QBL_PRIMITIVE_CUSTODY_AND_ORTHAD_LAW_v2.md` is the strongest written statement of the intended system and controls over later summaries, diagrams, inspiration papers, and agent reconstructions.

The inspiration papers may clarify geometry, orientation, overlap, conservation, lifting, and transfer. They may not overturn an explicit statement in the primary authority.

Interpretive corrections required by the user's direct clarification:

```text
“primitive custody”
    means the retained primitive state X_t and its own predicates;
    it is not a separate controller or selector mechanism.

“the current lifted state determines the next primitive”
    must factor through X_t alone;
    Orthad data does not participate.

“the Orthad mutates after the primitive is selected”
    means inside the same atomic tick;
    it does not mean delayed post-processing.
```

## 1. Primitive engine

The primitive engine is autonomous.

The retained primitive state is

\[
X_t=(A_t,q_t,\theta_t,k_t,j_t,W_t),
\qquad q_t=(u_t,v_t).
\]

Its own current predicates self-determine the next primitive under strict priority

```text
B > Q > L
```

There is no separate selector object, scheduler, Orthad decision, or external operator word.

Removing the Orthad leaves the primitive evolution unchanged.

Current exact results:

```text
first word:                 BQQBBBQBQBBQBBL
first completed pair:       (55,89)
first completed product:    4895
Q count before first L:     5
pair and phase through L:   carried
first next-domain step:     B
first next-domain pair:     (89,144)
L quarter turn:             none
```

## 2. One atomic primitive-and-Orthad tick

Every primitive step is immediately also an Orthad step.

Let

\[
U_t=\Sigma(X_t),
\]

where `Sigma` is only notation for the primitive-state predicates.

The complete transition is atomic:

\[
\widehat X_t\xrightarrow{\;U_t\;}\widehat X_{t+1}.
\]

During that one tick:

```text
U_t updates X_t;
the same U_t acts on Omega_t+ and Omega_t- simultaneously;
U_t updates the common retained Orthad relation P_t in that same tick;
a cross-chart transfer/reconciliation substep follows the two local chart mutations;
the complete new lifted state is retained;
only then does X_{t+1} self-determine the next primitive.
```

There are not separate primitive operators `U_t+` and `U_t-`. The one selected
primitive is applied to both charts. Their results may differ because the chart
states have counter-oriented local frames and different retained contents.

It is unlawful to execute primitive steps first and update the matrices later.

The Orthad does not select, permit, block, veto, or alter the next primitive.

## 3. Fully retained lifted state and Orthad

The fully retained lifted state is represented schematically by

\[
\widehat X_t=
\left(
X_t,
P_t,
\Omega_t^+,
\Omega_t^-,
T_t^{+\to-},
T_t^{-\to+}
\right).
\]

The Orthad is the exact deterministic dual-chart reader/geometry wrapping this retained state.

It is not:

```text
a primitive selector
a scheduler
a single diagonal matrix
a post-L attachment
a scalar
the lifted object itself
a bank of terminal projectors
```

It is:

```text
two word-built opposed chart matrices;
two directed overlap transfers;
an evolving geometry present at every B/Q/L prefix;
the structure constraining lawful terminal descent.
```

The Orthad wraps and reads the lifted object. It never replaces it.

## 4. Pairing-first architecture

Pairing-first is restored as the intended internal architecture.

The primary pairing `P_t` is generative. The two chart matrices and both directed transfers are not independently invented outputs. They are chart-local and cross-chart descendants of the same updated primary object.

The intended algebraic shape is

\[
\Omega_t^+=\iota_{+,t}^{*}P_t\iota_{+,t},
\qquad
\Omega_t^-=\iota_{-,t}^{*}P_t\iota_{-,t},
\]

\[
T_t^{+\to-}=\iota_{-,t}^{*}P_t\iota_{+,t},
\qquad
T_t^{-\to+}=\iota_{+,t}^{*}P_t\iota_{-,t}.
\]

These formulas state the required direction of construction. They do not yet type the star, the argument objects, the chart maps, the pairing carrier, or the exact recurrence.

Pairing-first is an internal dependency within one tick. It is not a delayed temporal pipeline.

For one primitive event `U_t`, all of the following belong to the same transition:

```text
P_t -> P_{t+1}
Omega_t+ -> Omega_{t+1}+
Omega_t- -> Omega_{t+1}-
T_t(+->-) -> T_{t+1}(+->-)
T_t(- ->+) -> T_{t+1}(- ->+)
```

The matrix descendants must be generated non-vacuously from the updated primary structure. They may not be independently chosen to force agreement.

## 5. Original dual-matrix vision

The inspiration papers clarify how to interpret the chart descendants without overturning pairing-first.

The Orthad's visible matrix realization consists of two coexisting matrices with opposite or complementary orientations.

For every selected primitive `U_t`, the same operator acts on both chart matrices at once:

\[
(\widetilde\Omega_{t+1}^+,\widetilde\Omega_{t+1}^-)
=
U_t\cdot(\Omega_t^+,\Omega_t^-).
\]

The tilde marks the state immediately after the simultaneous chart-local mutation
and before cross-chart transfer/reconciliation. Different chart results come from
the two counter-oriented chart states, not from replacing `U_t` by a different,
inverse, split, or chart-specific primitive operator.

This same-operator action must remain coherent with the updated `P_{t+1}` and the
cross-chart structure.

Thus one `B` tick means:

```text
X_t self-selects B;
that same B updates the primitive pair;
that same B mutates Omega+ and Omega- simultaneously;
P is updated as the common retained Orthad relation in that same tick;
then any required cross-chart transfer/reconciliation is applied;
then the complete next state is retained.
```

The same applies to `Q` and `L`.

“Opposite” does not yet mean any one of:

```text
negative
inverse
transpose
conjugate transpose
fixed rotation
dual object
```

The exact opposition law remains open.

### Same-operator counter-orientation lock

The settled geometric reading is the same world operation applied to two local
frames that face in opposite directions. The operator is one. The chart states
are counter-oriented. Complementary outputs arise from that retained orientation
difference.

The metriplectic `J/M` analogy is licensed only as an analogy for complementarity.
It does not license splitting one primitive into two independent operators.

## 6. Per-primitive Orthad behavior

### B

`B` changes the active arithmetic anchor and refinement width while preserving phase and all previously latched structure.

Required same-tick behavior:

```text
update the active primary-pairing data from the new pair;
update both chart matrices in their own orientations;
update both directed transfers;
preserve every latched axis;
preserve accumulated Q phase;
do not project.
```

### Q

`Q` advances phase by one quarter turn while preserving the arithmetic pair and architectural size.

Required same-tick behavior:

```text
rotate active primary-pairing orientation;
update both chart matrices under their opposed orientations;
update both directed transfers;
preserve every latched axis;
preserve the arithmetic anchor;
do not project.
```

Visible four-turn repetition does not identify the lifted state because the exact word, positions, and retained history differ.

### L

`L` carries pair and phase, closes the completed active direction, and opens one new active direction.

User-ratified intended behavior:

```text
freeze the completed active axis;
retain all old structure;
append one new active independent/orthogonal direction;
extend the primary pairing;
extend both chart matrices;
extend both directed transfers;
preserve the relation between the two orientation hands;
do not project.
```

Formal boundary:

```text
architectural direction count +1: intended and structurally active
exact algebraic meaning of orthogonal: not yet typed
algebraic rank of P rises by one: intended, not yet independently proved
mixed and new-new pairing values: not yet derived
```

## 7. Overlap and transfer

Neither chart is globally sufficient by itself.

The two directed transfers are active state components carrying information between the two opposed chart orientations.

The current tick order is:

```text
1. the same selected primitive mutates both chart matrices simultaneously;
2. the directed cross-chart transfer/reconciliation acts on the post-mutation charts;
3. the complete coupled state is retained;
4. only then may the primitive state self-select the next letter.
```

The transfer stage is not a second primitive and does not participate in primitive
selection. It is also not a terminal comparison or a later repair of an already
completed evolution.

The exact transfer recurrence, and whether every tick requires a nontrivial handoff,
remain open. Any lawful transfer law must satisfy:

```text
same-tick completion
orientation awareness
bidirectional consistency
exact-word dependence
non-vacuous dependence on the common primary structure
no independently selected target values
no projection during evolution
```

The overset-grid papers support reversible orientation change, transformed component handoff, and possible conservation constraints across overlap. They do not by themselves determine the QBL transfer recurrence.

## 8. Exact local witness

Before the first `L`, the exact Domain-0 local witness is

\[
a_t=\frac{i^{\#Q(W_t)}}{u_tv_t}.
\]

Its exact local updates are

\[
B:a\mapsto a\frac{u}{u+v},
\qquad
Q:a\mapsto ia.
\]

At the first `L`,

\[
a_{\mathrm{completed},0}=\frac{i}{4895}
\]

is the completed Domain-0 old-axis descendant.

It is not yet identified with:

```text
a Hermitian diagonal
the complete primary pairing
a particular chart block
a transfer block
a global all-domain active-axis recurrence
the complete retained object
```

## 9. Pre-Orthad lineage

The earlier Phase Calculus papers worked without an Orthad and repeatedly built branch-specific substitutes:

```text
filters and projectors
sheet and history registers
completion coordinates
branch guards
recovery maps
commuting descent tests
monodromy records
negative controls
```

These papers show the pressure that produced the Orthad.

The primitive engine already evolved autonomously. What was missing was one reusable intrinsic geometry that evolved with every primitive and preserved relations among multiple lawful views before terminal descent.

The old filters and branch registers are precursor constructions and calibration targets. They are not the Orthad itself.

## 10. Projection boundary

No projection occurs during retained evolution.

Terminal projection happens only after the complete primitive-and-Orthad evolution has halted.

A visible recurrence or equal terminal value does not imply equality of retained states.

The completed Orthad must already have fixed the lawful descent geometry. Terminal projection may not search for a chart, infer missing state, or repair an incomplete evolution.

## 11. Downstream FQM, gauge, and Weil status

The intended downstream chain remains:

```text
retained QBL history
-> word-built pairing-first Orthad
-> overlap/cocycle/holonomy data
-> finite quadratic module presentation
-> gauge/isometry class
-> terminal Weil/shadow descent
```

Substantial finite FQM and Weil work has been salvaged as exact conditional mathematics, calibration data, obstruction data, and tooling.

Until the all-prefix primary-pairing, chart-map, and transfer recurrences are derived, the downstream corpus may not be cited as proof that the clean Orthad already generates every legacy FQM object.

## 12. Guardrails

- The primitive state alone self-selects `B`, `Q`, or `L`.
- Removing the Orthad does not change primitive evolution.
- Every primitive tick immediately mutates all Orthad components.
- Pairing-first does not mean delayed matrix mutation.
- The same primitive operator acts on both chart matrices simultaneously.
- Different chart results come from counter-oriented chart state, not different primitive operators.
- The primitive operator is not split, inverted, or replaced between charts.
- A chart or transfer descendant may not be independently fitted.
- A bare equation `D=R(P)` is vacuous if `R` encodes the desired target.
- The star notation is not yet typed.
- A nonzero imaginary local witness cannot be promoted to a Hermitian self-pairing diagonal.
- One-sided orthogonality does not force both mixed blocks to vanish.
- Architectural axis growth and algebraic rank must remain distinct until typed.
- A finite carrier cannot retain an unbounded exact word injectively.
- No RST macro grammar, fixed window, fixed schedule, or external word may replace the primitive law.

## 13. Active constructive target

The next derivation must preserve both explicit authorities:

```text
pairing-first internal construction
same-tick opposed dual-matrix mutation
```

The smallest faithful target is the first complete `B` transition:

\[
\left(
X_0,P_0,\Omega_0^+,\Omega_0^-,T_0^{+\to-},T_0^{-\to+}
\right)
\xrightarrow{B}
\left(
X_1,P_1,\Omega_1^+,\Omega_1^-,T_1^{+\to-},T_1^{-\to+}
\right).
\]

It must determine or isolate exactly:

```text
P_0;
the intrinsic B action on P;
the effect of the same B on the + chart state;
the effect of the same B on the - chart state;
the post-B cross-chart transfer/reconciliation;
the opposition/coherence law encoded by the chart states;
the non-vacuous relation from P_1 to all four descendants.
```

A new name for the missing law is not progress.

## 14. Compact whole-system statement

```text
The primitive state is autonomous and self-determines B, Q, or L.

The selected primitive immediately mutates the primitive state and applies the
same operator to both opposed chart matrices simultaneously during one atomic
tick. The common primary relation is updated in that same tick.

After the simultaneous chart-local mutation, directed cross-chart transfer or
reconciliation completes the Orthad tick before the next primitive is selected.

The two matrices are orientation-specific expressions of the same updated
primary structure. Their different local results come from their counter-oriented
states, not from separate, inverse, or chart-specific primitive operators.

The Orthad never participates in primitive selection and is not required for
the primitive engine to run.

No projection occurs until the retained evolution is complete.
```
