# Canonical Research Trunk

**Revision:** v3  
**Purpose:** Preserve the current intended behavior of the primitive engine, lifted object, and Orthad without importing later formal language that changes their causal order.

## 0. Evidence classes

Every statement in this trunk belongs to one of four classes.

```text
USER-RATIFIED INTENT
    The user's direct statement of what the object is supposed to do.

CURRENT-CANON RESULT
    A result already derived or exactly reproduced under the current primitive law.

PROVISIONAL FORMALIZATION
    A mathematical model that may express the intent but is not yet the object itself.

INSPIRATION OR CALIBRATION
    External mathematics or earlier Phase Calculus work that supplies tests, analogies,
    or downstream tools without defining the Orthad.
```

When plain-language intent and later terminology conflict, the plain-language intent controls until the formal equivalence is proved.

---

## 1. Primitive engine

### User-ratified behavior

The primitive engine is autonomous.

The current primitive retained state determines whether the next operation is `B`, `Q`, or `L` through its own state conditions and strict priority:

```text
B > Q > L
```

There is no separate selector object, custody mechanism, scheduler, or Orthad decision.

Removing the Orthad leaves the primitive evolution unchanged.

### Current-canon exact results

The retained primitive state contains at least

\[
X_t=(A_t,q_t,\theta_t,k_t,j_t,W_t),
\qquad q_t=(u_t,v_t).
\]

The exact first word is

```text
BQQBBBQBQBBQBBL
```

The first completed pair is

\[
(55,89),
\qquad 55\cdot 89=4895,
\]

with five `Q` steps. Pair and phase carry through `L`. The first next-domain step is

\[
(55,89)\xrightarrow{B}(89,144).
\]

`L` does not add a quarter turn.

---

## 2. Same-tick Orthad law

### User-ratified behavior

Every primitive step is immediately also an Orthad step.

A primitive is determined from the current primitive state. That primitive then mutates the primitive state and every present Orthad component during the same tick. The full updated state exists before the next primitive is determined.

It is not lawful to execute several primitive steps and update the matrices later.

The causal order is:

```text
current primitive state self-determines U_t in {B,Q,L}
-> U_t immediately updates the primitive state
-> the same U_t immediately updates both Orthad matrices in their own ways
-> the same U_t immediately updates the overlap/transfer data
-> the complete updated lifted state is retained
-> only then does the next primitive self-determine
```

A compact formal shell is

\[
U_t=\Sigma(X_t),
\]

where `Sigma` is only notation for the state predicates, followed by one atomic transition

\[
(X_t,\mathcal O_t)\xrightarrow{U_t}(X_{t+1},\mathcal O_{t+1}).
\]

The Orthad is driven by the primitive evolution. It does not drive, permit, block, veto, or select the primitive.

---

## 3. Initial dual-matrix Orthad vision

### User-ratified intent

The Orthad begins as two coexisting matrix-valued lenses or grids.

The two matrices are opposite or complementary to one another. Each has its own orientation or nature. The same primitive event acts on both, but it need not produce the same local matrix update in each.

For every primitive `U`:

\[
M^+_{t+1}=\Phi^+_U(\widehat X_t),
\qquad
M^-_{t+1}=\Phi^-_U(\widehat X_t).
\]

The superscripts do not yet assert positive and negative scalar signs. They identify the two opposed orientations.

The two update laws may differ because the matrices occupy different orientations. They must remain related through the Orthad's opposition and overlap law.

Thus a `B` step means:

```text
B mutates M+ according to the B law seen from the + orientation.
B mutates M- according to the B law seen from the - orientation.
Both mutations occur during that B tick.
The overlap relation is updated during that same tick.
```

The same applies to `Q` and `L`.

### What "opposite" does not yet mean

The exact algebraic meaning of opposition is open. It has not yet been proved to mean any one of:

```text
M- = -M+
M- = inverse(M+)
M- = transpose(M+)
M- = conjugate-transpose(M+)
M- = a fixed rotation of M+
M- = a dual object
```

An involutive or reversible chart transformation is a strong candidate shape, but it is not yet the derived Orthad law.

---

## 4. Common-object consistency without premature pairing ontology

The two matrices are not unrelated outputs. They are two coordinated views or realizations of one retained evolution.

Their local values and transfers may not be chosen afterward to force agreement with a desired projection.

At every tick, the complete prior state and the selected primitive must deterministically produce:

```text
updated + matrix
updated - matrix
updated + to - transfer
updated - to + transfer
```

The exact common object that makes these four updates coherent remains open.

Later research introduced a primary object `P_t` and treated the two matrices and transfers as restrictions or placements of `P_t`. That remains a useful candidate formalization, but it is no longer stated here as settled causal ontology.

The currently safe requirement is:

> There must be one non-vacuous consistency law connecting both matrices and both directions of transfer at every exact word prefix.

Open possibilities include:

```text
A. one underlying retained object has two matrix presentations;
B. the relation between the two matrices is itself the primary retained object;
C. the two matrices and their opposition law are jointly generated;
D. a two-slot pairing P_t is the correct common object;
E. P_t is reconstructed from the dual-matrix system rather than updated before it.
```

No option may be promoted without showing that it reproduces the ratified same-tick dual-matrix behavior.

### Status of pairing-first research

```text
PAIRING-FIRST AS A CANDIDATE FORMALIZATION:
    retained

PAIRING-FIRST AS THE ONLY RATIFIED ONTOLOGY:
    withdrawn pending semantic proof

EXACT PRIMARY PAIRING TYPE, SEED, AND B/Q/L RECURRENCE:
    not yet derived
```

The pairing work remains useful as a search for the common consistency law. It may not redefine the original Orthad behavior.

---

## 5. Overlap and transfer

The matrices overlap. Neither matrix is globally sufficient by itself.

The two directed transfers express how retained structure is carried between the two orientations. They are active parts of the Orthad state and mutate on every primitive tick.

The transfers are not terminal comparison functions and are not repairs applied after matrix evolution.

A minimal current shell is

\[
\mathcal O_t=
\left(
M_t^+,
M_t^-,
T_t^{+\to-},
T_t^{-\to+}
\right).
\]

The exact transfer law remains open, but it must satisfy:

```text
same-tick update
orientation awareness
bidirectional consistency
exact-word dependence
no independently selected target values
no projection during evolution
```

A conservation, cocycle, or commuting-overlap law may be required. The exact law is not yet derived.

---

## 6. Lifted object and Orthad boundary

The primitive state, lifted object, and Orthad are not the same thing.

```text
primitive state:
    autonomously executes B/Q/L

lifted object:
    retains the complete evolving content and history

Orthad:
    the driven dual-matrix reader/geometry that evolves with every primitive
    and constrains lawful descent
```

The Orthad wraps or reads the lifted object. It does not become the lifted object.

Removing the Orthad does not stop the primitive state from evolving. It removes the intrinsic dual-view descent geometry, forcing later applications to reconstruct filters, projectors, branch registers, and recovery rules manually.

---

## 7. Projection boundary

No projection occurs during retained evolution.

The matrices and transfers do not compare candidate terminal outputs, select a chart, or collapse the state while `B/Q/L` evolution is still active.

Terminal projection occurs only after the retained computation has completed.

A visible repetition or equal projected value does not imply equality of lifted states.

---

## 8. Exact local witness

Before the first `L`, the exact Domain-0 local witness is

\[
a_t=\frac{i^{\#Q(W_t)}}{u_tv_t}.
\]

Its current exact local updates are

\[
B:a\mapsto a\frac{u}{u+v},
\qquad
Q:a\mapsto ia.
\]

At the first `L`,

\[
a_{\mathrm{completed},0}=\frac{i}{4895}
\]

is the completed Domain-0 old-axis descendant.

It is not yet identified with:

```text
a diagonal entry of both Orthad matrices
a self-pairing
a transfer value
a global all-domain active-axis formula
the complete retained object
```

The newborn active direction remains distinct.

---

## 9. Pre-Orthad lineage

The earlier Phase Calculus papers worked without an Orthad.

They repeatedly constructed branch-specific substitutes:

```text
filters and projectors
sheet and history registers
completion coordinates
branch guards
recovery maps
commuting descent tests
monodromy records
negative controls
```

Those constructions show why the Orthad became necessary. The primitive engine already evolved autonomously. The missing object was a reusable intrinsic geometry that could evolve with every primitive and preserve the relation among lawful views before terminal descent.

The filter systems in *Operational Utility and Multiscale Invariance* and the descent papers are direct precursors. They remain calibration targets, not the Orthad itself.

---

## 10. Inspiration-paper findings

### Strong direct anchor: Yin-Yang overset grids

The axis-free Yin-Yang grid papers provide the closest external structural analogue found in the supplied set.

They use two geometrically identical grid patches that cover one global sphere in different orientations. One patch is obtained from the other by rotations. In the axis-free construction, the coordinate transformation is involutive:

\[
M^{-1}=M.
\]

Vector components must be transformed when moving between the two patch coordinate systems. Each patch evolves the same physical field in its own coordinates, while overlap data is interpolated and transformed between patches.

This strongly supports the following Orthad interpretation:

```text
one retained evolution
two complementary oriented matrix realizations
the same primitive event applied in both local orientations
bidirectional overlap transport
an opposition map that may be reversible or involutive
```

It does not prove that the Orthad matrices are negatives, inverses, adjoints, or restrictions of a prior pairing.

### Conservation across overlap

The conservative-overlapping-grid papers show that local interpolation agreement is insufficient. The transfer law may need additional constraints so that a global invariant is preserved across overlap.

This supports a non-vacuous Orthad transfer requirement:

> Cross-lens transfer must preserve the global retained content, not merely copy or fit local values.

The exact Phase Calculus invariant preserved by the transfers remains open.

### Cech and sheaf language

Cech cohomology and cellular sheaves provide formal languages for:

```text
local data on overlapping regions
overlap maps
compatibility conditions
global sections assembled from consistent local data
cocycle failure as an obstruction
```

These are useful for expressing consistency between the two matrices and their overlap.

They do not decide the Orthad's dynamics or prove that the two matrices are passive restrictions of a pre-existing object. Their role is provisional consistency language.

### Homotopy lifting

Path and homotopy lifting support the distinction between a visible/base trajectory and a retained lifted trajectory. A visible return can occur while the lifted path remains different because its history or sheet is different.

This is a useful formal analogue for retained phase and word history. It is not the matrix update law.

### Asynchronous automata and trace monoids

The asynchronous-automata papers provide a useful dynamical analogy: one shared action can update multiple local processes, with each process changing according to its own local state and shared-action rule.

This closely matches the ratified statement:

```text
one primitive B/Q/L event
-> immediate + matrix update
-> immediate - matrix update
-> synchronization through overlap data
```

They do not supply the Orthad geometry.

### Downstream and physical references

The finite quadratic module, Weil representation, lattice, MHD, solar-topology, beam-transmission, and heterogeneous-domain papers remain useful as downstream targets, physical analogues, or external tooling.

They do not define the initial dual-matrix Orthad or its primitive update law.

---

## 11. Inspiration-source disposition

| Source | Salvaged role | Boundary |
|---|---|---|
| *An Axis-Free Overset Grid in Spherical Polar Coordinates* | Strong dual-grid geometry, rotated identical patches, involutive coordinate transform, vector transfer | Numerical grid analogue, not the Orthad law |
| *Discontinuous Galerkin Transport on the Spherical Yin-Yang Overset Mesh* | Same transport law in two orientations, overlap flux transfer, conservation pressure | Does not derive QBL actions |
| *A Scheme for Conservative Interpolation on Overlapping Grids* | Constraints preventing overlap transfer from violating global conservation | Does not identify the preserved Orthad invariant |
| *Interface Control Domain Decomposition for Stokes-Darcy Coupling* | Coupled subdomains and interface control | Heterogeneous PDE tool, not core ontology |
| *Global Attractors for a Full von Karman Beam Transmission Problem* | Transmission dynamics and global attractor methods | Supplemental dynamical analogy |
| *A Gentle Introduction to Sheaves on Graphs* | Local data, restriction maps, consistency, global sections | Consistency language only |
| *Notes on Cech Cohomology* | Overlap gluing, transition functions, cocycle conditions | Does not provide tick dynamics |
| *Mathlib.Topology.Homotopy.Lifting* | Unique lifted paths and retained path information | History/lift analogy only |
| *Synthesising Asynchronous Automata from Fair Specifications* | Shared actions update local states and synchronize | No matrix geometry |
| *Uniform Generation in Trace Monoids* | Partial commutation and exact word/path structure | Supplemental symbolic tool |
| *Weil Representations Associated to Finite Quadratic Modules* | Downstream finite representation machinery | Requires a proved Orthad-to-FQM bridge |
| *Finite Quadratic Modules and Lattices* | Decomposition and explicit Gram-matrix targets | Downstream calibration only |
| *Data-Constrained MHD Simulation...* | Physical field evolution and reconnection inspiration | Physical analogue, not formal law |
| *Topological Methods for Solar Magnetic Fields* | Topology, separatrices, nulls, robust global features | External physical/topological tooling |
| *An Almost Complete Disappearance of Open-Flux Polar Cap...* | Dual-lobe and magnetic-reconnection inspiration | Metaphorical/physical reference only |

---

## 12. Exact arithmetic salvage

The v7y arbitrary-start `B` ladder remains compatible with the exact `B` mutation. Its continuant matrices, inverse recovery, and unimodular wedge identities can be retained as primitive arithmetic.

Its projection conclusions remain calibration results rather than state-completeness theorems.

---

## 13. Guardrails proved by counterexample or source audit

- A nonzero imaginary local trace cannot be a Hermitian diagonal self-pairing.
- One-sided orthogonality does not force both mixed blocks to vanish.
- Adding one architectural direction does not force algebraic pairing rank to rise.
- A represented form `P:H->D(H)` requires an additional representability or duality law.
- Four specific local-view obligations do not imply a global two-slot bifunctor.
- A finite carrier cannot retain the exact infinite word history injectively.
- A bare formula `D=R(P)` is vacuous when `R` can encode a desired target.
- A common-object formalization may not delay or replace same-tick matrix mutation.
- A common-object formalization may not make the Orthad participate in primitive selection.
- The two matrices may not be independently fitted to a terminal answer.

---

## 14. Active open problems

The next constructive work must preserve the dual-matrix vision rather than starting by choosing a pairing category.

The first questions are:

```text
1. What is the exact opposition relation between M+ and M-?

2. Given one primitive B, what changes immediately in M+?

3. Given the same B, what changes immediately in M- because of its opposite orientation?

4. What overlap quantity must remain consistent or conserved after both updates?

5. Are the transfers fixed transformations, state-dependent transformations,
   or parts of the two matrix updates themselves?

6. Does a common primary object emerge from these laws, or must one be added?

7. If a primary pairing is used, can it reproduce the dual-matrix updates without
   changing their causal order?
```

The minimal constructive target is one complete first tick:

\[
(X_0,M_0^+,M_0^-,T_0^{+\to-},T_0^{-\to+})
\xrightarrow{B}
(X_1,M_1^+,M_1^-,T_1^{+\to-},T_1^{-\to+}).
\]

A new name for the missing law is not progress. The pass must either compute this transition or identify one exact missing semantic statement from the user-ratified vision.

---

## 15. Compact whole-system statement

```text
The primitive state is autonomous and self-determines B, Q, or L.

Every primitive step immediately mutates the primitive state and both opposed
Orthad matrices during the same tick.

Each matrix receives the same primitive event through its own orientation-specific
update law.

The directed overlap data mutates during that same tick and keeps both views
consistent with one retained evolution.

The Orthad does not select the primitive and is not required for the primitive
engine to run.

No projection occurs until the retained evolution is complete.

A primary pairing is a candidate formalization of the common relation, not yet a
ratified replacement for the original dual-matrix behavior.
```
