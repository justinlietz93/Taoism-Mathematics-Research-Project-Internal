# Canonical Research Trunk

These claims can be carried directly into new work without importing the legacy successor-first or projection-first interpretations.

## Primitive engine

- Exact custody tuple and strict `B > Q > L` selector.
- Exact first word `BQQBBBQBQBBQBBL`.
- Exact floor `(55,89)`, product `4895`, five quarter-turns.
- Pair and phase carry through `L`; first next-domain `B` gives `(89,144)`.

## Pairing-first architecture

- One primary object is upstream of two chart restrictions and two directed transfers.
- The Orthad mutates after the custody-selected primitive and never selects the primitive.
- No descendant may be independently chosen to force agreement.
- No projection occurs during the retained evolution.

## Exact local witness

- Before the first `L`, `a=i^(#Q(W))/(uv)`.
- `B` and `Q` obey the exact local updates recorded in the current authority.
- `i/4895` is the completed Domain-0 old-axis descendant only.

## Exact arithmetic salvage

The v7y arbitrary-start B-ladder is compatible with the exact B mutation. Its continuant matrices, inverse recovery, and unimodular wedge identities can be retained as custody arithmetic. Its projection conclusions remain calibration results, not state-completeness theorems.

## Guardrails proved by counterexample

- A nonzero imaginary local trace cannot be a Hermitian diagonal self-pairing.
- One-sided orthogonality does not force both mixed blocks to vanish.
- Adding one architectural axis does not force algebraic pairing rank to rise.
- A represented form `P:H->D(H)` requires an additional representability/duality law.
- Four specific restriction obligations do not imply a global two-slot bifunctor.
- A finite carrier cannot retain the exact infinite word history injectively.
